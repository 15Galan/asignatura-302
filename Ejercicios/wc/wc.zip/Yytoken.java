public class Yytoken {
    
}
