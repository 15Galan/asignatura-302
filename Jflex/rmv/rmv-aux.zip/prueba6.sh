saludo=Hola\;
frase="$saludo \"\$saludo\""
saludo=Adios
echo $frase
