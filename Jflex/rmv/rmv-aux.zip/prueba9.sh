Alfa=Alfa
beTa232="$Alfa Beta"
_gamma_123="$Alfa $beTa232 $_gamma_123"
_=""
_412="412";
echo $Alfa $beTa232 $_ $_gamma_123
